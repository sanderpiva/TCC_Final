package com.example.tcc_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
